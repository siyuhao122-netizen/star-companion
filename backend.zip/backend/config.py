﻿import os
from urllib.parse import quote_plus   # 必须导入

BASE_DIR = os.path.abspath(os.path.dirname(__file__))


class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key-change-this'

    # MySQL 连接字符串格式：mysql+pymysql://用户名:密码@主机:端口/数据库名
    DB_USER = os.environ.get('DB_USER') or 'xingban'
    DB_PASSWORD = os.environ.get('DB_PASSWORD') or 'xingban@123'
    DB_HOST = os.environ.get('DB_HOST') or 'localhost'
    DB_PORT = os.environ.get('DB_PORT') or '3307'   # 注意你的端口是 3307
    DB_NAME = os.environ.get('DB_NAME') or 'star_companion'

    # 对密码进行URL编码，处理特殊字符
    encoded_password = quote_plus(DB_PASSWORD)

    # 只保留这一个 URI 定义，使用编码后的密码
    SQLALCHEMY_DATABASE_URI = f"mysql+pymysql://{DB_USER}:{encoded_password}@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_recycle': 3600,
        'pool_pre_ping': True,
    }

    CORS_ORIGINS = ['http://localhost:5500', 'http://127.0.0.1:5500']