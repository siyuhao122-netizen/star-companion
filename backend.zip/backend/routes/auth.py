﻿from flask import Blueprint, request, jsonify
from models import db, User
from flask_bcrypt import generate_password_hash, check_password_hash

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    if User.query.filter_by(phone=data['phone']).first():
        return jsonify({'error': '手机号已注册'}), 400

    hashed = generate_password_hash(data['password']).decode('utf-8')
    user = User(phone=data['phone'], password_hash=hashed, nickname=data.get('nickname'))
    db.session.add(user)
    db.session.commit()
    return jsonify({'id': user.id, 'phone': user.phone}), 201


@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(phone=data['phone']).first()
    if not user or not check_password_hash(user.password_hash, data['password']):
        return jsonify({'error': '手机号或密码错误'}), 401

    return jsonify({
        'id': user.id,
        'phone': user.phone,
        'nickname': user.nickname,
        'avatar': user.avatar
    })