﻿from flask import Blueprint, request, jsonify
from models import db, NameReactionRecord, PointGameRecord, VoiceGameRecord
from datetime import date
import os

games_bp = Blueprint('games', __name__)

# ---------- 叫名反应 ----------
@games_bp.route('/name-reaction', methods=['POST'])
def save_name_reaction():
    data = request.json
    record = NameReactionRecord(
        child_id=data['child_id'],
        session_date=date.today(),
        round_total=data.get('round_total', 8),
        success_count=data['success_count'],
        avg_reaction_time=data.get('avg_reaction_time'),
        round_details=data.get('round_details', []),
        video_path=data.get('video_path')  # 录像文件路径
    )
    db.session.add(record)
    db.session.commit()
    return jsonify({'id': record.id}), 201

@games_bp.route('/name-reaction/history/<int:child_id>', methods=['GET'])
def get_name_history(child_id):
    records = NameReactionRecord.query.filter_by(child_id=child_id).order_by(
        NameReactionRecord.session_date.desc()).limit(10).all()
    return jsonify([{
        'id': r.id,
        'session_date': r.session_date.isoformat(),
        'success_count': r.success_count,
        'round_total': r.round_total,
        'avg_reaction_time': r.avg_reaction_time,
        'video_path': r.video_path,
        'round_details': r.round_details
    } for r in records])

# ---------- 指物练习 ----------
@games_bp.route('/point-game', methods=['POST'])
def save_point_game():
    data = request.json
    record = PointGameRecord(
        child_id=data['child_id'],
        session_date=date.today(),
        correct_count=data['correct_count'],
        wrong_count=data.get('wrong_count', 0),
        total_clicks=data.get('total_clicks', 0),
        timeout_count=data.get('timeout_count', 0),
        skip_count=data.get('skip_count', 0),
        total_time_sec=data.get('total_time_sec'),
        avg_time_sec=data.get('avg_time_sec'),
        accuracy=data.get('accuracy'),
        round_details=data.get('round_details', [])
    )
    db.session.add(record)
    db.session.commit()
    return jsonify({'id': record.id}), 201

# ---------- 声音小话筒 ----------
@games_bp.route('/voice-game', methods=['POST'])
def save_voice_game():
    data = request.json
    record = VoiceGameRecord(
        child_id=data['child_id'],
        session_date=date.today(),
        total_stars=data['total_stars'],
        round_details=data.get('round_details', [])
    )
    db.session.add(record)
    db.session.commit()
    return jsonify({'id': record.id}), 201