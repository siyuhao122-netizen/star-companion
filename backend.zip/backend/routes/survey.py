﻿from flask import Blueprint, request, jsonify
from models import db, SurveyResult
from datetime import date

survey_bp = Blueprint('survey', __name__)

@survey_bp.route('/submit', methods=['POST'])
def submit_survey():
    data = request.json
    result = SurveyResult(
        child_id=data['child_id'],
        answers=data['answers'],
        total_score=data['total_score'],
        level=data['level'],
        summary=data['summary'],
        suggestions=data['suggestions']
    )
    db.session.add(result)
    db.session.commit()
    return jsonify({'id': result.id}), 201

@survey_bp.route('/latest/<int:child_id>', methods=['GET'])
def get_latest_survey(child_id):
    result = SurveyResult.query.filter_by(child_id=child_id).order_by(
        SurveyResult.created_at.desc()).first()
    if not result:
        return jsonify({}), 200
    return jsonify({
        'id': result.id,
        'answers': result.answers,
        'total_score': result.total_score,
        'level': result.level,
        'summary': result.summary,
        'suggestions': result.suggestions,
        'created_at': result.created_at.isoformat()
    })