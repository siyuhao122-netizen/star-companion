﻿from flask import Blueprint, request, jsonify
from models import db, Child

child_bp = Blueprint('child', __name__)

@child_bp.route('/list/<int:user_id>', methods=['GET'])
def get_children(user_id):
    children = Child.query.filter_by(user_id=user_id).all()
    return jsonify([{
        'id': c.id, 'name': c.name, 'age': c.age, 'gender': c.gender,
        'avatar': c.avatar, 'birth_date': c.birth_date.isoformat() if c.birth_date else None
    } for c in children])

@child_bp.route('/add', methods=['POST'])
def add_child():
    data = request.json
    child = Child(
        user_id=data['user_id'],
        name=data['name'],
        age=data.get('age'),
        gender=data.get('gender'),
        avatar=data.get('avatar'),
        birth_date=data.get('birth_date')
    )
    db.session.add(child)
    db.session.commit()
    return jsonify({'id': child.id}), 201