﻿from flask import Blueprint, request, jsonify
from models import db, TreeholeMessage

treehole_bp = Blueprint('treehole', __name__)

@treehole_bp.route('/messages', methods=['GET'])
def get_messages():
    tag = request.args.get('tag')
    query = TreeholeMessage.query
    if tag:
        query = query.filter_by(tag=tag)
    messages = query.order_by(TreeholeMessage.created_at.desc()).limit(50).all()
    return jsonify([{
        'id': m.id,
        'anonymous_name': m.anonymous_name,
        'anonymous_avatar': m.anonymous_avatar,
        'content': m.content,
        'tag': m.tag,
        'ai_reply': m.ai_reply,
        'likes': m.likes,
        'comments': m.comments,
        'created_at': m.created_at.isoformat()
    } for m in messages])

@treehole_bp.route('/post', methods=['POST'])
def post_message():
    data = request.json
    msg = TreeholeMessage(
        user_id=data.get('user_id'),
        anonymous_name=data.get('anonymous_name'),
        anonymous_avatar=data.get('anonymous_avatar'),
        content=data['content'],
        tag=data.get('tag'),
        ai_reply=data.get('ai_reply')  # 前端生成或后端调用AI
    )
    db.session.add(msg)
    db.session.commit()
    return jsonify({'id': msg.id}), 201

@treehole_bp.route('/like/<int:msg_id>', methods=['POST'])
def like_message(msg_id):
    msg = TreeholeMessage.query.get(msg_id)
    if msg:
        msg.likes += 1
        db.session.commit()
        return jsonify({'likes': msg.likes})
    return jsonify({'error': '消息不存在'}), 404