﻿from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import JSON   # 从 sqlalchemy 导入 JSON 类型
from datetime import datetime

# 先创建 db 对象
db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)
    nickname = db.Column(db.String(50))
    avatar = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    children = db.relationship('Child', backref='parent', lazy=True)
    messages = db.relationship('TreeholeMessage', backref='author', lazy=True)

class Child(db.Model):
    __tablename__ = 'child'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(50), nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(10))
    avatar = db.Column(db.String(50))
    birth_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    name_records = db.relationship('NameReactionRecord', backref='child', lazy=True)
    point_records = db.relationship('PointGameRecord', backref='child', lazy=True)
    voice_records = db.relationship('VoiceGameRecord', backref='child', lazy=True)
    survey_results = db.relationship('SurveyResult', backref='child', lazy=True)

class NameReactionRecord(db.Model):
    __tablename__ = 'name_reaction_record'
    id = db.Column(db.Integer, primary_key=True)
    child_id = db.Column(db.Integer, db.ForeignKey('child.id'), nullable=False)
    session_date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    round_total = db.Column(db.Integer, default=8)
    success_count = db.Column(db.Integer)
    avg_reaction_time = db.Column(db.Float)
    round_details = db.Column(JSON)   # 直接使用 JSON 类型
    video_path = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class PointGameRecord(db.Model):
    __tablename__ = 'point_game_record'
    id = db.Column(db.Integer, primary_key=True)
    child_id = db.Column(db.Integer, db.ForeignKey('child.id'), nullable=False)
    session_date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    round_total = db.Column(db.Integer, default=8)
    correct_count = db.Column(db.Integer)
    wrong_count = db.Column(db.Integer)
    total_clicks = db.Column(db.Integer)
    timeout_count = db.Column(db.Integer)
    skip_count = db.Column(db.Integer)
    total_time_sec = db.Column(db.Float)
    avg_time_sec = db.Column(db.Float)
    accuracy = db.Column(db.Float)
    round_details = db.Column(JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class VoiceGameRecord(db.Model):
    __tablename__ = 'voice_game_record'
    id = db.Column(db.Integer, primary_key=True)
    child_id = db.Column(db.Integer, db.ForeignKey('child.id'), nullable=False)
    session_date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    round_total = db.Column(db.Integer, default=8)
    total_stars = db.Column(db.Integer)
    round_details = db.Column(JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SurveyResult(db.Model):
    __tablename__ = 'survey_result'
    id = db.Column(db.Integer, primary_key=True)
    child_id = db.Column(db.Integer, db.ForeignKey('child.id'), nullable=False)
    answers = db.Column(JSON)
    total_score = db.Column(db.Integer)
    level = db.Column(db.String(20))
    summary = db.Column(db.Text)
    suggestions = db.Column(JSON)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class TreeholeMessage(db.Model):
    __tablename__ = 'treehole_message'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    anonymous_name = db.Column(db.String(50))
    anonymous_avatar = db.Column(db.String(10))
    content = db.Column(db.Text, nullable=False)
    tag = db.Column(db.String(20))
    ai_reply = db.Column(db.Text)
    likes = db.Column(db.Integer, default=0)
    comments = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)